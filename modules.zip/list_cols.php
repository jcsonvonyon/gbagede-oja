<?php
require_once 'includes/db.php';
$stmt = $pdo->query("DESCRIBE transactions");
$cols = $stmt->fetchAll(PDO::FETCH_COLUMN);
echo implode(", ", $cols) . "\n";
?>
